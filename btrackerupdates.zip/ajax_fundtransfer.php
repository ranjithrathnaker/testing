<?php
require 'dbconfig.php';
require 'Authentication.php';
$userid=$_SESSION['Userid'];
$function=$_GET['functn'];
$value=$_GET['value'];
if($function=='fundtransfer_touser')
{
$query="SELECT UserID,UserName FROM user_m where UserID!='$userid'";
$sql=DataBasefunction($query);
echo '<option value="">SELECT</option>';
	while($row=mysqli_fetch_array($sql))
	{
	echo '<option value="'.$row['UserID'].'">'.decryption($row['UserName']).'</option>';}
}
else if($function=='fundtransfer_username')
 	{
$query="SELECT UserName FROM user_m where UserID='$value'";
$sql=DataBasefunction($query);
$row=mysqli_fetch_array($sql);
echo decryption($row['UserName']);
	 }
else if($function=='cashbalancechecking')
{
$query="CALL fundtransferdetail('$userid')";
$sql=DataBasefunction($query);
$row=mysqli_fetch_array($sql);
if(($row['cashinhand']-$row['amountpendingout'])<$value)
{
echo '';}
else
{
echo $value;}}
else if($function=='cashbalancemessage')
{
	
$query="CALL fundtransferdetail('$userid')";
$sql=DataBasefunction($query);
$row=mysqli_fetch_array($sql);
if(($row['cashinhand']-$row['amountpendingout'])<$value)
{
/*echo '<script type="text/javascript">
alert("No sufficient balance for fund transfer");
</script>';*/
echo 'No Balance';}
else
{
echo '';}}

else if($function=='subordinates')
{   
    
	$query="SELECT UserID,UserName FROM user_m WHERE MgmtLevel<(SELECT MgmtLevel FROM user_m WHERE UserID='$userid')and MgmtLevel!='0'";
	$sql=DataBasefunction($query);
    echo '<option value="">SELECT</option>
	<option value="allsubordinates">ALL</option>';
	while($row=mysqli_fetch_array($sql))
	{
	echo '<option value="'.$row['UserID'].'">'.decryption($row['UserName']).'</option>';
	}}
//subordinates transaction log 
else if($function=='subordinates_transactionlog')
{   
    $companytranlog=$_COOKIE['company_trsnctnlog'];
	$query="SELECT UserID,UserName FROM user_m WHERE MgmtLevel<(SELECT MgmtLevel FROM user_m WHERE UserID='$userid')
	AND UserID IN(SELECT UserID FROM usercompany_lnk WHERE CompanyID='$companytranlog') and MgmtLevel!='0'";
	$sql=DataBasefunction($query);
    echo '<option value="">SELECT</option>
	<option value="allsubordinates">ALL</option>';
	while($row=mysqli_fetch_array($sql))
	{
	echo '<option value="'.$row['UserID'].'">'.decryption($row['UserName']).'</option>';
	}}
	
	
//subordinates cashinhand
else if($function=='subordinates_cashinhand')
{   
    
	$query="SELECT UserID,UserName FROM user_m WHERE MgmtLevel<(SELECT MgmtLevel FROM user_m WHERE UserID='$userid')
			AND UserID IN(SELECT UserID FROM usercompany_lnk WHERE CompanyID IN
			(SELECT CompanyID FROM usercompany_lnk WHERE UserID='$userid')) and MgmtLevel!='0' or UserID in(SELECT SubUser FROM user_m WHERE UserID='$userid')";
	$sql=DataBasefunction($query);
    echo '<option value="">SELECT</option>
	<option value="allsubordinates">ALL</option>';
	while($row=mysqli_fetch_array($sql))
	{
	echo '<option value="'.$row['UserID'].'">'.decryption($row['UserName']).'</option>';
	}}
//subordinates for deleted report
else if($function=='subordinates_deletedreport')
{   
    $company_deleted=$_COOKIE['company_deleted'];
	if($_SESSION['Mngmntlevel']==0)
	{
	$query="SELECT UserID,UserName FROM user_m WHERE UserID IN(SELECT UserID FROM usercompany_lnk WHERE CompanyID='$company_deleted') and MgmtLevel!='0'";
	}
	else
	{
	$query="SELECT UserID,UserName FROM user_m WHERE MgmtLevel<(SELECT MgmtLevel FROM user_m WHERE UserID='$userid')
			AND UserID IN(SELECT UserID FROM usercompany_lnk WHERE CompanyID='$company_deleted') and MgmtLevel!='0'";
	}
	$sql=DataBasefunction($query);
	 
    echo '<option value="">SELECT</option>
	<option value="allsubordinates">ALL</option>';
	while($row=mysqli_fetch_array($sql))
	{
	echo '<option value="'.$row['UserID'].'">'.decryption($row['UserName']).'</option>';
	}}
	
//subordinates-bank transfer report
else if($function=='BankTransfer_subordinates')
{   
   $company_bankreprt=$_COOKIE['company_BankTranReport'];
   
	$query="SELECT UserID,UserName FROM user_m WHERE MgmtLevel<(SELECT MgmtLevel FROM user_m WHERE UserID='$userid')
			AND UserID IN(SELECT UserID FROM usercompany_lnk WHERE CompanyID='$company_bankreprt') and MgmtLevel!='0'";
	$sql=DataBasefunction($query);
    echo '<option value="">SELECT</option>';
	
	while($row=mysqli_fetch_array($sql))
	{
	echo '<option value="'.$row['UserID'].'">'.decryption($row['UserName']).'</option>';
	}}
//subordinates delete financial tran 
else if($function=='subordinates_delete')
{   
   $company_delete=$_COOKIE['company_deletefinacial'];
    if($_SESSION['Mngmntlevel']==0)
	{
	$query="SELECT UserID,UserName FROM user_m WHERE UserID IN(SELECT UserID FROM usercompany_lnk WHERE CompanyID='$company_delete') and MgmtLevel!='0'";
	}
   else
   {
	$query="SELECT UserID,UserName FROM user_m WHERE MgmtLevel<(SELECT MgmtLevel FROM user_m WHERE UserID='$userid')
			AND UserID IN(SELECT UserID FROM usercompany_lnk WHERE CompanyID='$company_delete') and MgmtLevel!='0'";
   }
	$sql=DataBasefunction($query);
    echo '<option value="">SELECT</option><option value="allsubordinates">ALL</option>';
	
	while($row=mysqli_fetch_array($sql))
	{
	echo '<option value="'.$row['UserID'].'">'.decryption($row['UserName']).'</option>';
	}}
	
else if($function=='subordinates_edit')
{   
   $company_delete=$_COOKIE['company_editfinacial'];
    if($_SESSION['Mngmntlevel']==0)
	{
	$query="SELECT UserID,UserName FROM user_m WHERE UserID IN(SELECT UserID FROM usercompany_lnk WHERE CompanyID='$company_delete') and MgmtLevel!='0'";
	}
   else
   {
	$query="SELECT UserID,UserName FROM user_m WHERE MgmtLevel<(SELECT MgmtLevel FROM user_m WHERE UserID='$userid')
			AND UserID IN(SELECT UserID FROM usercompany_lnk WHERE CompanyID='$company_delete') and MgmtLevel!='0'";
   }
	$sql=DataBasefunction($query);
    echo '<option value="">SELECT</option>';
	 echo ' <option value="allsubordinates">All</option>';
	
	while($row=mysqli_fetch_array($sql))
	{
	echo '<option value="'.$row['UserID'].'">'.decryption($row['UserName']).'</option>';
	}}
//cashin hand list fo cash in hand report - on trans criteria selection 
else if($function=='CashInHandList')
	{
		if($value=='mytran')
		{
		$UserCondition="UserID='$userid'";
		}
		else if($value=='allsubordinates')
			{
				$UserCondition="UserID in(SELECT UserID FROM user_m WHERE 
						MgmtLevel<(SELECT MgmtLevel FROM user_m WHERE UserID='$userid')
						AND UserID IN(SELECT UserID FROM usercompany_lnk WHERE CompanyID IN
			(SELECT CompanyID FROM usercompany_lnk WHERE UserID='$userid')))";
			}
			else 
			{
				$UserCondition="UserID=$value";
				}
				$query="SELECT UserID,UserName,CashInHand FROM user_m WHERE $UserCondition";
				$sql=DataBasefunction($query);
				echo '<tr><th>NAME</th><th>CASH IN HAND</th><th></th>';
				while($row=mysqli_fetch_array($sql))
				{
					if($row['CashInHand']!='')
					{
				echo '<tr><td>'.decryption($row['UserName']).'</td><td>'.$row['CashInHand'].'</td>
				<td>';
				?>
				<a href="CashInHand_Report_detail.php" class="btn btn-outline btn-success btn-sm"
				onClick="setusercookie('<?php echo $row['UserID'];?>')">DETAIL</a>
				</td></tr>
				<?php
					}
				}
	}
else if($function=="CASHINHANDDETAIL")
	{
		$date=$_COOKIE['date'];
		$todate=$_COOKIE['todate'];
	
		$query="SELECT FinancialTranID,BusinessDate,TranType,vendor_m.VendorName,TranMode,CashAmount FROM 
				vendor_m INNER JOIN financial_tran ON vendor_m.VendorID=financial_tran.VendorID WHERE 
				financial_tran.BusinessDate between '$date' and '$todate' AND financial_tran.UserID='$value'
				and CashAmount!='0'";
		$sql=DataBasefunction($query);
		$query2="SELECT FinancialTranID,BusinessDate,TranType,vendor_m.VendorName,TranMode,CashAmount
				 FROM del_financial_tran INNER JOIN vendor_m ON vendor_m.VendorID=del_financial_tran.VendorID
				 WHERE del_financial_tran.BusinessDate BETWEEN '$date' AND '$todate' AND del_financial_tran.UserID='$value'
				 AND CashAmount!='0'";
		$sql2=DataBasefunction($query2);
		$query3="SELECT FundTransferID,user_m.UserName,TransferAmount,ToUserActionDateTime,'FUNDTRANSFER' FROM 
				fundtransfer_tran INNER JOIN user_m ON user_m.UserID=fundtransfer_tran.FromUserID 
				WHERE ToUserID='$value' AND (ToUserActionDateTime BETWEEN (SELECT '$date' - INTERVAL 1 SECOND) 
				AND (SELECT '$todate' + INTERVAL 1 DAY - INTERVAL 1 SECOND)) AND ToUserAction='ACCEPTED'";
		$sql3=DataBasefunction($query3);
		$query4="SELECT FundTransferID,user_m.UserName,TransferAmount,ToUserActionDateTime,'FUNDTRANSFER' FROM 
				fundtransfer_tran INNER JOIN user_m ON user_m.UserID=fundtransfer_tran.ToUserID 
				WHERE FromUserID='$value' AND (ToUserActionDateTime BETWEEN (SELECT '$date' - INTERVAL 1 SECOND) 
				AND (SELECT '$todate' + INTERVAL 1 DAY - INTERVAL 1 SECOND)) AND ToUserAction='ACCEPTED'";
		$sql4=DataBasefunction($query4);
		while($row=mysqli_fetch_array($sql))
		{
		$creditedamount=(decryption($row['TranType'])=="CREDIT")?'0.00':$row['CashAmount'];
		$debitedamount=(decryption($row['TranType'])=="DEBIT")?'0.00':$row['CashAmount'];
		echo '<tr><td>'.$row['BusinessDate'].'</td><td>'.decryption($row['VendorName']).'</td><td>'.$row['TranMode'].'</td><td>'.
		      $creditedamount.'</td><td>'.$debitedamount.'</td></tr>';
		}
		while($row2=mysqli_fetch_array($sql2))
		{
		$creditedamount=(decryption($row2['TranType'])!="CREDIT")?'0.00':$row2['CashAmount'];
		$debitedamount=(decryption($row2['TranType'])!="DEBIT")?'0.00':$row2['CashAmount'];
		echo '<tr><td>'.$row2['BusinessDate'].'</td><td>'.decryption($row2['VendorName']).'</td><td>'.$row2['TranMode'].' -Deleted</td><td>'.
		      $creditedamount.'</td><td>'.$debitedamount.'</td></tr>';
		}
		while($row3=mysqli_fetch_array($sql3))
		{
		$creditedamount=$row3['TransferAmount'];
		$debitedamount='0.00';
		echo '<tr><td>'.date("Y-m-d",strtotime($row3['ToUserActionDateTime'])).'</td><td>'.decryption($row3['UserName']).'</td>
		<td>'.$row3['FUNDTRANSFER'].'</td><td>'.
		      $creditedamount.'</td><td>'.$debitedamount.'</td></tr>';
		}
		while($row4=mysqli_fetch_array($sql4))
		{
		$creditedamount='0.00';
		$debitedamount=$row4['TransferAmount'];
		echo '<tr><td>'.date("Y-m-d",strtotime($row4['ToUserActionDateTime'])).'</td><td>'.decryption($row4['UserName']).'</td>
		<td>'.$row4['FUNDTRANSFER'].'</td><td>'.
		      $creditedamount.'</td><td>'.$debitedamount.'</td></tr>';
		}
		
	}
	/////////////////
	else if($function=='edit_listview')
{
	
$user=$_SESSION['Userid'];
$cmbnytype=($_SESSION['AllowProvTransaction']=="N")?'C':"C','P";
$company=$_COOKIE["company_editfinacial"];
$date=$_COOKIE["date_editfinancial"];
$todate=$_COOKIE["todate_editfinancial"];
$trantype=$_COOKIE["trantype_editfinancial"];
$subordinate=$_COOKIE["subordinate_editfinancial"];
$datetype=$_COOKIE["datetype_editfinancial"];
$query1="SELECT CompanyName FROM company_m WHERE CompanyID='$company'";
$sql1=DataBasefunction($query1);
$row=mysqli_fetch_array($sql1);
setcookie("done",null, time() +100);

 /*<div class="col-lg-12">
                        <!--<h1 class="page-header">EDIT FINANCIAL TRANSACTION - <?php echo decryption($row['CompanyName']); ?></h1>-->*/
                      
if(($datetype=='default')||($datetype=='BusinessDate'))
	{
	$DateCondition="(BusinessDate BETWEEN '$date' and '$todate')";
	}
	else if($datetype=='TranDate')
		{
		$DateCondition="(TranDate BETWEEN (SELECT '$date' - INTERVAL 1 SECOND)AND(SELECT '$todate' + INTERVAL 1 DAY - INTERVAL 1 SECOND))";
		}
		else
			{
			$DateCondition="(BusinessDate BETWEEN '$date' and '$todate')";	
			}
if($trantype=='mytran')
	{
	$UserCondition="financial_tran.UserID='$user'";
	}
	else if(($subordinate!='')&&($subordinate!='allsubordinates'))
		{
		$UserCondition="financial_tran.UserID='$subordinate'";	
		}
		else if($subordinate=='allsubordinates')
			{
			$UserCondition="financial_tran.UserID in (SELECT UserID FROM user_m WHERE MgmtLevel<(SELECT MgmtLevel FROM user_m
			 WHERE UserID='$user'))";
			}
$query="SELECT FinancialTranID,vendor_m.VendorName,user_m.UserName,ledger_m.LedgerName,BusinessDate,TaxTran,TranType,TranMode,BankAmount,CashAmount,TranTotalAmt,
        LedgerGroupName,Description
	FROM financial_tran INNER JOIN vendor_m ON vendor_m.VendorID=financial_tran.VendorID
	INNER JOIN user_m ON financial_tran.UserID=user_m.UserID
	INNER JOIN ledger_m ON ledger_m.LedgerID=financial_tran.LedgerID
	INNER JOIN ledgergroup_m ON ledgergroup_m.LedgerGroupID=ledger_m.LedgerGroupID WHERE 
	$UserCondition AND financial_tran.CompanyID='$company' AND $DateCondition and VerifyStatus='N'";
$sql=DataBasefunction($query);	

echo '<div class="table-responsive">
<table class="table table-hover table-responsive" id="dataTables-example" >
<thead>
<tr><th>DATE</th><th>LEDGER GRP</th><th>USER</th><th>VENDOR</th><th>TRAN MODE</th><th>BILL</th><th>CASH</th><th>BANK</th><th></th></tr></thead><tbody>';

if($sql)
{
	while($row=mysqli_fetch_array($sql))
	{
		if($row['TaxTran']==null)
		{
		
		echo '<tr title="'.decryption($row['Description']).'"><td>'.$row['BusinessDate'].'</td><td>
		 '.$row['LedgerGroupName'].'</td><td>'.decryption($row['UserName']).'</td><td>'.decryption($row['VendorName']).'</td><td>'.$row['TranMode'].'
         </td><td>'.$row['TranTotalAmt'].'</td><td>'.$row['CashAmount'].'
		</td><td>'.$row['BankAmount'].'</td><td>
		<a href="#"
          class="btn btn-outline btn-danger btn-sm"
       onClick="return valdation1('.$row['FinancialTranID'].');">EDIT</a>
       <a href="EditFinacialTransaction_verification.php?id='.$row['FinancialTranID'].'"
        rel="facebox"  class="btn btn-outline btn-success btn-sm" onClick="facereload()">VIEW</a>';
        
		echo '</td></tr>';
		}
		}}
echo '</tbody></table> 
<table class="table table-hover">
<tr><td align="center" colspan="5"><a href="EditFinancialTransaction.php" class="btn btn-outline btn-warning btn-sm">CANCEL</a></td></tr>
</table></div>
                    </div>';
 }
//
?>