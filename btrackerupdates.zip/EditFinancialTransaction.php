<?php
error_reporting(0);
require 'Authentication.php';
if($_SESSION['EditFinTranFlg']=='N')
{
header("location:index.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
	<title>EditFINANCIALTRANSACTION-Btracker-craysol group</title>
<link href="../bower_components/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="../bower_components/metisMenu/dist/metisMenu.min.css" rel="stylesheet">
<link href="../dist/css/sb-admin-2.css" rel="stylesheet">
<link href="../bower_components/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link href="../textillate-master/assets/animate.css" rel="stylesheet">
<script src="../bower_components/jquery/dist/jquery.min.js"></script>

  <!-- DataTables Responsive CSS -->
    <link href="../bower_components/datatables-responsive/css/dataTables.responsive.css" rel="stylesheet">
    <link href="../textillate-master/assets/animate.css" rel="stylesheet">
    <script src="../bower_components/jquery/dist/jquery.min.js"></script>
    <style>
	.dataTables_scrollBody thead{visibility:hidden;}
	</style>
</head>
<body>
<div id="wrapper">
<?php

//require 'dbconfig.php';
require "menu.php";
require 'Functions_html.php';
$divid=$_COOKIE["divid"];
$user=$_SESSION['Userid'];
//$cmbnytype=($_SESSION['AllowProvTransaction']=="N")?'C':"C','P";
menu();
?>
 <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">EDIT FINANCIAL TRANSACTION</h1>
   <?php
   if($_SESSION['Mngmntlevel']==0)
   {
	$query="SELECT company_m.CompanyID,CompanyName FROM company_m WHERE CompanyStatus='Y'";
    }
	else
	{
$query="SELECT company_m.CompanyID,CompanyName FROM company_m INNER JOIN usercompany_lnk ON company_m.CompanyID=usercompany_lnk.CompanyID
		WHERE CompanyStatus='Y' AND usercompany_lnk.UserID='$user'";
	}
$sql=DataBasefunction($query);
	
?>

<form method="post">
<div class="table-responsive">
<table class="table table-hover">
<tbody>
<tr><th>COMPANY</th><td colspan="4"><select id="company" name="company" required autofocus>
<option value="">SELECT</option>
<?php
while($row=mysqli_fetch_array($sql))
{
	if(isset($_COOKIE['company_editfinacial'])&& ($row['CompanyID']==$_COOKIE['company_editfinacial']))
{
			
echo '<option value="'.$row['CompanyID'].'" selected="selected">'.decryption($row['CompanyName']).'</option>';
setcookie("company_editfinacial",null,time()-3000);
	}
	else
	echo '<option value="'.$row['CompanyID'].'">'.decryption($row['CompanyName']).'</option>';
}

?>
</select></td></tr>
<tr><th>DATE FROM </th><td><input type="text" id="date" name="date" required max="<?php echo date('Y-m-d'); ?>" 
value="<?php if(isset($_COOKIE['date_editfinancial'])){ echo $_COOKIE['date_editfinancial'];setcookie ("date_editfinancial", null, time() - 3600); }?>" ></td>
<th>TO</th><td><input type="text" id="todate" name="todate" value="<?php echo date('Y-m-d'); ?>" ></td>
<th><input type="radio" id="BusinessDate" name="Datetype" value="BusinessDate" checked="checked"> Effect Date
    <input type="radio" id="TranDate" name="Datetype" value="TranDate"> TranDate</th></tr>
<tr><th>TRANS CRITERIA</th><td colspan="4">
<select id="trantype" name="trantype">
<option value="">SELECT</option>
<option value="mytran">MY TRANSACTION</option>
<option value="subtran">SUBORDINATES TRANS</option>
</select>
<select id="trantype1" name="trantype1">
  <option value="">SELECT</option>
  <option value="allsubordinates">All</option>
</select></td></tr></tbody>
</table>
</div>
</form>
</div>
                    </div>
                    <!------------->
                <div class="row" >
                <div class="col-md-12" id="list_display">
               
                </div>
                </div>
                    </div>
                </div>
          
     </div>
     
<style>
 #popup {
   width:360px;
  height:auto;
  background-color:#C8C8C8 ;
  border-radius: 10px;
  border:8px solid #029FFD;
box-shadow: 10px 10px 5px #888888;
    display:none;
position: absolute;
    top: 50%;
    left: 50%;
    margin-top: -180px;
    margin-left: -180px;
}
</style>
<div id="popup">
    <div align="center"><h4>Enter Tran Password:</h4></div>
    <table align="center"><tr ><td align="center">
    <input id="pass" type="password" class="form-control"
value="";required onKeyUp="close_error()"/></td></tr>
         <tr><td height="53" align="left" >
    <button id="ok1" onclick="done('<?php echo $function;?>')"
class="btn btn-primary ">OK</button>
   &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp;
     <button  onclick="close1()" class="btn btn-default ">Close</button>
    </td>
    </tr>
    <tr><td align="center"><img id="danger"  src="Danger.png"
style="width:40px;height:40px"> <font color="#FF0000"><br>
    <label id="passwordresult"></label></font></td></tr></table>
</div>
          
     </div>
 <script src="../bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
 <script src="../bower_components/metisMenu/dist/metisMenu.min.js"></script>
 <script src="../dist/js/sb-admin-2.js"></script>
 <script type="text/javascript" src="JS/javascript_editTransaction.js"></script>
 <script type="text/javascript">
    document.write('<link href="JS/jquery-ui-1.11.4.custom/jquery-ui.css" rel="stylesheet" type="text/css" />\n')
    document.write('<script src="JS/jquery-ui-1.11.4.custom/jquery-ui.min.js"><\/script>\n') 
    jQuery(function($){ 
    $('#date').datepicker({
    dateFormat: 'yy-mm-dd',
	maxDate: "+0"
});
$('#todate').datepicker({
    dateFormat: 'yy-mm-dd',
	maxDate: "+0"
});
})

</script>
    <!-- DataTables JavaScript -->
 <script src="../bower_components/datatables/media/js/jquery.dataTables.min.js"></script>
 <script src="../bower_components/datatables-plugins/integration/bootstrap/3/dataTables.bootstrap.min.js"></script>
    <script type="text/javascript"  defer="defer">
/*$(document).ready(function(){
   // $('#dataTables-example').DataTable();
	 var dataTable = $('#dataTables-example').dataTable({
         //sScrollX: "100%",
         aoColumns : [
          { "sWidth": "100px"},
          { "sWidth": "150px"},
          { "sWidth": "120px"},
          { "sWidth": "100px"},
          { "sWidth": "100px"},
		  { "sWidth": "90px"},
		  { "sWidth": "90px"},
		  { "sWidth": "50px"},
		   { "sWidth": "150px"}
        ],
		stateSave: true,
		"aoColumnDefs": [
		{'bSortable':false,'aTargets':[4,5,6,7,8]}],
		stateSave: true,
		sScrollY: "100%",
		"searching": true
		
    });
});*/
</script>
<link href="facebox/facebox.css" media="screen" rel="stylesheet" type="text/css"/>
<script src="facebox/facebox.js"></script>
<script type="text/javascript">
function facereload()
{
      $('a[rel*=facebox]').facebox({//apply all anchor tag which has rel=facebox attribute
        loadingImage : 'facebox/loading.gif',
        closeImage   : 'facebox/closelabel.png'
      })
    }
    jQuery(document).ready(function($) {
      $('a[rel*=facebox]').facebox({//apply all anchor tag which has rel=facebox attribute
        loadingImage : 'facebox/loading.gif',
        closeImage   : 'facebox/closelabel.png'
      })
    });
</script>
 
<script type="text/ecmascript">
document.cookie="datetype_editfinancial=default";
$("input[name=Datetype]").click(function(){
	var datetype=document.querySelector('input[name="Datetype"]:checked').value;
	document.cookie="datetype_editfinancial="+datetype;
	
});
</script>

 </body>
 </html>
