// JavaScript Document
$(document).ready(function(e) {
	setcookie();
	$(document).keypress(function(e) {
   if(e.which == 13) {
       if(document.getElementById("popup").style.display=="block")
$('#ok1').click();
}
});
	
  $('#company').change(function(){
	  var company=document.getElementById('company').value;
	  document.cookie="company_editfinacial="+company;
	redirecting();
	  });  
$('#date').change(function(){
	redirecting();
	});
$('#trantype').change(function(){
	redirecting();
	});
$('#trantype1').change(function(){
	redirecting();
	});
});
function redirecting()
{
	var trantype=document.getElementById('trantype');
if((trantype.value=='')||(document.getElementById('date').value=="")||(document.getElementById('company').value==""))
	{
	if(document.getElementById('company').value=="")
			{
			//alert("select the company");
			document.getElementById('company').focus();
			}
		else if(document.getElementById('date').value=="")
			{
			//alert("select from date");
			document.getElementById('date').focus();
			}
		else if(trantype.value=="")
		   {
		//alert("select trans type");
		trantype.focus();}
		 }
		else if(trantype.value=='mytran')
			{   
			setcookie();
			$("#trantype1").hide();
			ajaxloadedit('edit_listview','list_display','date');
			//window.location="EditFinacialTransaction_Listview.php";
			}
			else if(trantype.value=='subtran')
				{
					$("#trantype1").show();
				ajaxload('subordinates_edit','trantype1','date');
				if(document.getElementById('trantype1').value=="")
				{
					//alert("select subordinates");
					document.getElementById('trantype1').focus();
				}
			else if(document.getElementById('trantype1').value=='allsubordinates')
				{
					
				setcookie();
				ajaxloadedit('edit_listview','list_display','date');
				 /*$('#dataTables-example').dataTable({
         //sScrollX: "100%",
         aoColumns : [
          { "sWidth": "100px"},
          { "sWidth": "150px"},
          { "sWidth": "120px"},
          { "sWidth": "100px"},
          { "sWidth": "100px"},
		  { "sWidth": "90px"},
		  { "sWidth": "90px"},
		  { "sWidth": "50px"},
		   { "sWidth": "150px"}
        ],
		stateSave: true,
		"aoColumnDefs": [
		{'bSortable':false,'aTargets':[4,5,6,7,8]}],
		stateSave: true,
		sScrollY: "100%",
		"searching": true
		
    });*/
				//$("#list_display").show();
				//window.location="EditFinacialTransaction_Listview.php";
				}
				else
					{
					setcookie();
					ajaxloadedit('edit_listview','list_display','date');
					//window.location="EditFinacialTransaction_Listview.php";
					}
					}
					}
function setcookie()
{
	var date=document.getElementById('date').value;
	var company=document.getElementById('company').value;
	var todate=document.getElementById('todate').value;
	var trantype=document.getElementById('trantype').value;
	var subordinate=document.getElementById('trantype1').value;
	document.cookie="company_editfinacial="+company;
	document.cookie="date_editfinancial="+date;
	document.cookie="todate_editfinancial="+todate;
	document.cookie="trantype_editfinancial="+trantype;
	document.cookie="subordinate_editfinancial="+subordinate;
	}
function valdation1(id)
{  
	

    
        var v=confirm("Are you sure");

	

	document.cookie="fintrans_id="+id;
	if(v==true)
	{
		showpopup();
		//var transpassword = prompt("Please enter your Transaction password");
		//if((transpassword!="")&&(transpassword!=null))
		//{
		//window.location="EditFinacialTransaction_passwordverification.php?id="+id+"&password="+transpassword;
		//return true;
		}
		else
		{
			return false;
			}}
/////////////////////////
function done()
{
	
	
	var password=document.getElementById("pass").value;
	document.getElementById("popup").style.display="none";
	if(password=="")
	{
		document.getElementById("popup").style.display="block";
		$("#pass").focus();
	}
	else
	{
		$.ajax({url: "EditFinacialTransaction_passwordverification.php?&password="+password, success: function(result){
                       
                        if(result==1)
						{
							window.location="EditFinacialTransaction_Form.php";
						}
						else
						{
							showpopup();
				document.getElementById("popup").style.border=" 9px solid red";
				document.getElementById("danger").style.display="block";
				$('#pass').val('');
				$('#pass').focus();
				$('#passwordresult').html("invalid tran password");
						}
                                                  }});
		//window.location="EditFinacialTransaction_passwordverification.php?&password="+transpassword;
		
	}
		
}	
////////////////////////
function valdation()
{  
	alert("inside the function");
	var v=confirm("Are you sure");
	if(v==true)
	{
		
		return true;
		}
		else
		{
		
		return false;
		}}
			

			
function ajaxload(functn,divid,elementid)
	{
	var value=document.getElementById(elementid).value;
	
	var a;
	if(window.XMLHttpRequest)
	{
	a=new XMLHttpRequest();
	
	}
		else
		{
		a=new ActiveXObject("microsoft.XMLHTTP");
		}
		a.onreadystatechange=function()
			{
			if(a.readyState==4&& a.status==200)
				{
				document.getElementById(divid).innerHTML=a.responseText;
				}}
				a.open("get","ajax_fundtransfer.php?functn="+functn+"&value="+value,true);
				a.send();
	}
	
	
	
	function ajaxloadedit(functn,divid,elementid)
	{
	var value=document.getElementById(elementid).value;
	
	var a;
	if(window.XMLHttpRequest)
	{
	a=new XMLHttpRequest();
	
	}
		else
		{
		a=new ActiveXObject("microsoft.XMLHTTP");
		}
		a.onreadystatechange=function()
			{
			if(a.readyState==4&& a.status==200)
				{
				document.getElementById(divid).innerHTML=a.responseText;
				$('#dataTables-example').dataTable({
         //sScrollX: "100%",
         aoColumns : [
          { "sWidth": "100px"},
          { "sWidth": "150px"},
          { "sWidth": "120px"},
          { "sWidth": "100px"},
          { "sWidth": "100px"},
		  { "sWidth": "90px"},
		  { "sWidth": "90px"},
		  { "sWidth": "50px"},
		   { "sWidth": "150px"}
        ],
		stateSave: true,
		"aoColumnDefs": [
		{'bSortable':false,'aTargets':[4,5,6,7,8]}],
		stateSave: true,
		sScrollY: "100%",
		"searching": true
		
    });
				}}
				a.open("get","ajax_fundtransfer.php?functn="+functn+"&value="+value,true);
				a.send();
	}
	
function close1()
{
		document.getElementById("popup").style.border=" 8px outset #029FFD";
		document.getElementById("popup").style.display="none"; 
		$('#passwordresult').html("");
		
	
}
//fuunction to show pop up for pswd varifiction
function showpopup()
{
	document.getElementById("popup").style.display="block";
	$('#pass').focus();
	document.getElementById("pass").value="";
	document.getElementById("danger").style.display="none";
	
}
