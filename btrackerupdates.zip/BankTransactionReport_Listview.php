<?php
error_reporting(0);
require 'Authentication.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
	<title>BankTransaction-Btracker-craysol group</title>
<link href="../bower_components/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="../bower_components/metisMenu/dist/metisMenu.min.css" rel="stylesheet">
<link href="../dist/css/sb-admin-2.css" rel="stylesheet">
<link href="../bower_components/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
 <link href="../bower_components/datatables-plugins/integration/bootstrap/3/dataTables.bootstrap.css" rel="stylesheet">
<link href="../bower_components/datatables-responsive/css/dataTables.responsive.css" rel="stylesheet">
 <script src="../bower_components/jquery/dist/jquery.min.js"></script>
</head>
<body>
<div id="wrapper">
<?php
//require 'dbconfig.php';
require "menu.php";
require 'Functions_html.php';
$divid=$_COOKIE["divid"];
$user=$_SESSION['Userid'];
//$value=$_GET['userid'];
$subordinate=$_COOKIE['subordinate_BankTranReport'];
$Bank_User=($_COOKIE['trantype_BankTranReport']=="mytran")?$user:$subordinate;
$company=$_COOKIE['company_BankTranReport'];
//$Bank_User="UserID='$user'";


$date=$_COOKIE['date_BankTranReport'];
$todate=$_COOKIE['todate_BankTranReport'];
menu();
//$balancequery="CALL OpeningAndClosingCashinhand((SELECT '$date' - INTERVAL 1 SECOND),$UserCondition="UserID='$userid'"
			  // (SELECT '$todate' + INTERVAL 1 DAY - INTERVAL 1 SECOND),'$value' )";
//$balancesql=DataBasefunction($balancequery);
$query="CALL BankTransactionReport((SELECT '$date' - INTERVAL 1 SECOND),
		(SELECT '$todate' + INTERVAL 1 DAY - INTERVAL 1 SECOND),'$Bank_User','$company')";
$sql=DataBasefunction($query);
//$balancerow=mysqli_fetch_array($balancesql);

//$openingbalance=($balancerow['cashinhand']+$balancerow['totaldebitedamount'])-($balancerow['totalcreditedamount']);
//$closingbalance=$openingbalance+($balancerow['creditedamount']-$balancerow['debitedamount']);
?>
<div id="page-wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">BANK TRANSACTION REPORT <?php //echo decryption($balancerow['username']);?></h1>
                       
<div class="table-responsive">
<table class="table table-hover">
<tbody>
<!--<tr><th width="30%">USERNAME </th><th colspan="2"><?php //echo decryption($balancerow['username']);?></th></tr>
<tr><th>OPENING BALANCE </th><th><?php //echo  number_format($openingbalance,2);
 ?></th><th width="50%"><?php //echo $date;?></th></tr>-->
<?php //echo'<tr><th>CLOSING BALANCE</th><th>'. number_format($closingbalance,2).'</th><th>'.$todate.'</th></tr>';?>
<table class="table table-striped table-bordered table-hover" id="dataTables-example">
<thead>
<tr><th>DATE</th><th>FROM/TO USER</th><th>DESCRIPTION</th><th>AMOUNT</th><th></th></tr>
</thead>
<tbody id="details">
<?php
while($row=mysqli_fetch_array($sql))
		{
			$amount=($row['DEBITEDAMOUNT']==0)?$row['CREDITEDAMOUNT']:$row['DEBITEDAMOUNT'];
		echo '<tr><td>'.$row['TRANSFERDATE'].'</td><td>'.decryption($row['FROMORTOUSER']).'</td><td>'.
		$row['DESCRIPTION'].'</td><td>'.$amount
		      .'</td><td>
			  <a href="BankTransactionReport_Detail.php?ID='.$row['ID'].'&function='.$row['QUERYDETAIL'].'" 
			  class="btn btn-outline btn-success btn-sm">DETAIL</a></td></tr>';
		}
	?>
</tbody></table>
</tbody></table>
<table class="table table-hover">
<tr><td align="center"><a href="BankTransactionReport.php" class="btn btn-outline btn-warning btn-sm">BACK</a></td></tr>
</table>

</div>
                    </div>
                    </div>
                </div>
          </div>
     </div>

 <script src="../bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
 <script src="../bower_components/metisMenu/dist/metisMenu.min.js"></script>
 <script src="../dist/js/sb-admin-2.js"></script>
 <script src="../bower_components/datatables/media/js/jquery.dataTables.min.js"></script>
    <script src="../bower_components/datatables-plugins/integration/bootstrap/3/dataTables.bootstrap.min.js"></script>
    <script type="text/javascript"  defer="defer">
	$(document).ready(function(){
    $('#dataTables-example').DataTable();
});
</script>
 <script type="text/javascript" src="JS/javascript_CashinHand.js"></script>
 <script type="text/javascript">
    var datefield=document.createElement("input")
    datefield.setAttribute("type", "date")
    if (datefield.type!="date")
	{ 
     document.write('<link href="JS/jquery-ui-1.11.4.custom/jquery-ui.css" rel="stylesheet" type="text/css" />\n')
     document.write('<script src="JS/jquery-ui-1.11.4.custom/jquery-ui.min.js"><\/script>\n') 
    }
if (datefield.type!="date")
   { 
    jQuery(function($){ 
    $('#date').datepicker({
    dateFormat: 'yy-mm-dd'
});
$('#todate').datepicker({
    dateFormat: 'yy-mm-dd'
});
})
}
</script>


 </body>
 </html>
