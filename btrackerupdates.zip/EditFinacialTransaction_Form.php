<?php
error_reporting(0);
session_start();
require 'Authentication.php';
if($_SESSION['EditFinTranFlg']=='N')
{
header("location:index.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
	<title>EDITFINANCIALTRANSACTION-Btracker-craysol group</title>
<link href="../bower_components/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="../bower_components/metisMenu/dist/metisMenu.min.css" rel="stylesheet">
<link href="../dist/css/sb-admin-2.css" rel="stylesheet">
<link href="../bower_components/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link href="../textillate-master/assets/animate.css" rel="stylesheet">
 <style>    
   
 #popupsucess
   {
   width:360px;
  height:auto;
  background-color:#C8C8C8 ;
  border-radius: 10px;
  border:8px solid #090;
box-shadow: 10px 10px 5px #888888;
    display:none;
color:green;
position: absolute;
    top: 50%;
    left: 50%;
    margin-top: -180px;
    margin-left: -180px;


}
</style>
<script src="../bower_components/jquery/dist/jquery.min.js"></script>
<script type="text/javascript"></script>
<script>
function deleteimg(i,j,k)
{
	var a=document.getElementById(i).value;
	var b=document.getElementById(j).value;
	
	window.location.href="delete_img.php?doc="+b+"& img="+a+"& tranid="+k;
	
}
</script>

</head>
<body>
<div id="wrapper">
<?php

//require 'dbconfig.php';
require "menu.php";
$divid=$_COOKIE["divid"];
$company=$_COOKIE['companyname'];
$user=$_SESSION['Userid'];
$financialtrnsctnid=$_COOKIE['fintrans_id'];
//$_GET['id'];
require 'Functions_html.php';
$query1="CALL financialtransaction_formsubmitte('$financialtrnsctnid')";
$sql1=DataBasefunction($query1);
$row1=mysqli_fetch_array($sql1);
$transaction_user=$row1['UserID'];
menu();
$companyid=$row1['CompanyID'];
$projectquery="SELECT BusinessProjectsID,BusinessProjectName FROM businessprojects WHERE CompanyID='$companyid'";
$projectsql=DataBasefunction($projectquery);


?>
 <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">EDIT FINANCIAL TRANSACTION -<?php echo decryption($row1['CompanyName']);?></h1>
                       <?php

$companyid=$company;
 ?>
<fieldset>
<div class="table-responsive">
<table class="table table-striped table-bordered table-hover table-responsive">
<tr><th>COMPANY</th><td>
<form method="post" onSubmit="return valdation1();" enctype="multipart/form-data">
<input type="hidden" id="trantype" name="trantype" value="<?php echo decryption($row1['TranType']); ?>">
<?php
$taxtotal=0;
echo decryption($row1['CompanyName']).'</td>
<th>DATE</th><td colspan="4">';
?>
<input type="text" name="businesdate" id="businessdate" value="<?php echo $row1['BusinessDate']; ?>">
<?php
echo '</td></tr>';
echo '<tr><th>TYPE</th><td>'.decryption($row1['TranType']).'</td>';
echo '<th>TRANS MODE</th><td colspan="4">'.$row1['TranMode'].'</td></tr>';
echo'<tr><th>LOCATION</th><td>'.$row1['LocationName'].'</td><th>VENDOR</th><td colspan="4">'.decryption($row1['VendorName']).'</td></tr>';

echo '<tr><th>LEDGER GRP/LEDGER</th><td>'.$row1['LedgerGroupName'].'/'.decryption($row1['LedgerName']).'</td>
<th>PROJECT</th><td colspan="4">';
?>
<select id="project" name="project" required>
<option value="">SELECT</option>
<?php
while($projectrow=mysqli_fetch_array($projectsql))
{
	?>
<option value="<?php echo $projectrow['BusinessProjectsID'];?>" <?php 
	echo ($row1['BusinessProjectsID']==$projectrow['BusinessProjectsID'])?"selected":""?>><?php echo decryption($projectrow['BusinessProjectName']);?></option>
<?php
}
?>
</select>
<?php
echo '</td></tr>
<tr><th>DESCRIPTION</th><td colspan="6"><textarea id="description" name="description" maxlength="100" cols="56" rows="3" required>'.decryption($row1['Description']).'</textarea></td></tr>';
if(($row1['TranMode']=='RECEIPTS')||($row1['TranMode']=='PAYMENTS'))
{
echo '<tr><th>BANK AMOUNT</th><th>BANK DOCNUMBER</th><th>CASH AMOUNT</th><th colspan="4">CASH DOCNUMBER</th></tr>
<tr><td >'.$row1['BankAmount'].' '.decryption($row1['CurrencyAbbr']).'</td>
<td>'.decryption($row1['BankDocNumber']).'</td>
<td>'.$row1['CashAmount'].' '.decryption($row1['CurrencyAbbr']).'</td>
<td colspan="4">'.decryption($row1['CashDocNumber']).'</td></tr>';
}

if(($row1['TranMode']!='RECEIPTS')&&($row1['TranMode']!='PAYMENTS'))
{
echo '<tr><th>BILL AMOUNT TOTAL</th><td>'.$row1['TranTotalAmt'].'</td><th>BILL NO</th><th colspan="2">'.$row1['TranDocNumber'].'</th></tr>';
}
if(($row1['TranMode']!='RECEIPTS')&&($row1['TranMode']!='PAYMENTS'))
{
$taxquery="SELECT TaxName,TaxAmount,GovFormName,GovDocStatus FROM financial_tax_tran INNER JOIN tax_m ON tax_m.TaxID=
financial_tax_tran.TaxID WHERE financial_tax_tran.FinancialTranID='$financialtrnsctnid'";
$taxsql=DataBasefunction($taxquery);
echo '<tr><th>
WRRNTY/ONCOST</th><td colspan="6">'.$row1['WarrantyOnCostType'].'</td></tr>';
$query="SELECT product_m.ProductName,uom.UOMName AS UOM,Qty,
financial_prod_tran.Rate,TotalDicount,TotalValue FROM financial_prod_tran INNER JOIN product_m
ON product_m.ProductID=financial_prod_tran.ProductID 
INNER JOIN uom ON uom.UOMId=financial_prod_tran.UOM WHERE 
financial_prod_tran.FinancialTranID='$financialtrnsctnid'";

echo '<tr><th>PRODUCT</th><th>Qty</th><th>RATE</th><th>DISCOUNT</th>
<th>TOTAL</th></tr>';
$sql=DataBasefunction($query);
while($row=mysqli_fetch_array($sql))
{
echo '<tr><td>'.decryption($row['ProductName']).'</td><td>'.$row['Qty'].' '.$row['UOM'].'</td>
<td>'.$row['Rate'].'</td>
<td>'.$row['TotalDicount'].'</td><td>'.$row['TotalValue'].'</td></tr>';
$discounttotal=$discounttotal+$row['TotalDicount'];
$sum=$sum+$row['TotalValue'];
}
echo '<tr><th colspan="2"></th><th>TOTAL</th><td>'.$discounttotal.'</td><td>'.$sum.'</td></tr>';
echo '<tr><th colspan="3"></th><th>LABOURCHARGE</th><td>'.$row1['LabourCharge'].'</td></tr>';
while($taxrow=mysqli_fetch_array($taxsql))
{
	$taxtotal=$taxtotal+$taxrow['TaxAmount'];
echo '<tr><th>';
if($taxrow['GovFormName']=="")
{

echo '</th><th colspan="2">';
}
else
{
echo $taxrow['GovFormName'].'</th><th colspan="2">'.$taxrow['GovDocStatus'];
}
echo '</th><th>'.$taxrow['TaxName'].'</th><th>'.$taxrow['TaxAmount'].'</th></tr>';
}
$labourcharge=$row1['LabourCharge'];
$grandtotal=$sum+$labourcharge+$taxtotal;
echo '<tr><th colspan="3"></th><th>GRAND TOTAL</th><td>'.$grandtotal.'</td></tr>';
echo '<tr><th colspan="3"></th><th>CASH DICOUNT</th><td>'.$row1['CashDiscount'].'</td></tr>';

$nettotal=$sum+$labourcharge+$taxtotal-$row1['CashDiscount'];
echo '<tr><th colspan="3"></th><th>NET TOTAL</th><td>'.$nettotal.'</td></tr>';
}

$query2="SELECT DocumentNumber,financial_doc_files.FilePath,param.FilePath as dir FROM financial_doc_files JOIN param
WHERE FinancialTranID='$financialtrnsctnid'";
$sql2=DataBasefunction($query2);
echo'<tr><th colspan="7" align="center">DOCUMENTS</th></tr>';
echo '<tr>';
$image=array();
$docnum=array();
while($row2=mysqli_fetch_array($sql2))
{
array_push($image,decryption($row2['FilePath']));
array_push($docnum,decryption($row2['DocumentNumber'])); 
}
$i=0;
foreach($image as $img)
{

echo '<td align="center"><input type="hidden" id="'.$i.'" value="'.$img.'"><img src="'.$img.'"height="150" width="120"></img></td>';$i++;}
echo '</tr><tr>';
$j=0;
$k=100;
foreach($docnum as $doc)
{
?><td align="center"><input type="hidden" id="<?php echo $k;?>" value="<?php echo $doc;?>">
<?php echo $doc;?> &nbsp;&nbsp;
<a href="#" onClick="deleteimg(<?php echo $j;?>,<?php echo $k;?>,<?php echo $financialtrnsctnid;?>)" class="button">
<font color='#FF0000'>X</font></a></td>;<?php
$j++;$k++;}
echo '</tr>';
echo '<tr><td colspan="7" align="center"><b>ADDITIONAL ATTACHMENTS</b></td></tr>';
?>
<tr class="Additionaldocument"><td  align="right" colspan="2">ATTACHMENT(1)</td><td> 
<input type="text" id="refnumber1" name="refnumber1" onChange="showdiv('#doc1')" style="text-transform:uppercase"></td><td>
<input type="file" id="document1" name="document1" onChange="showdiv('#doc1')"></td><td colspan="2">
<a href="#" id="doc1" name="refresh" onClick="refreshelements('refnumber1','#document1','#doc1')" class="button">
<font color='#FF0000'>X</font></a>
</td></tr>
<tr class="Additionaldocument"><td  align="right" colspan="2" >ATTACHMENT(2)</td><td>
<input type="text" id="refnumber2" name="refnumber2" onChange="showdiv('#doc2')" style="text-transform:uppercase"></td><td>
<input type="file" id="document2" name="document2" onChange="showdiv('#doc2')"></td><td colspan="2">
<a href="#" id="doc2" name="refresh" onClick="refreshelements('refnumber2','#document2','#doc2')" class="button">
<font color='#FF0000'>X</font></a></td></tr>
<tr class="Additionaldocument"><td  align="right" colspan="2">ATTACHMENT(3) </td><td>
<input type="text" id="refnumber3" name="refnumber3" onChange="showdiv('#doc3')" style="text-transform:uppercase"></td><td>
<input type="file" id="document3" name="document3" onChange="showdiv('#doc3')"></td><td colspan="2">
<a href="#" id="doc3" name="refresh" onClick="refreshelements('refnumber3','#document3','#doc3')" class="button">
<font color='#FF0000'>X</font></a>
</td></tr>



<?php
echo '<tr><td colspan="7" align="center">';
?>

<input type="submit" value="EDIT FINANCIALTRANSACTION" id="edit" name="edit" class="btn btn-outline btn-danger btn-sm">
<a href="EditFinancialTransaction.php" class="btn btn-outline btn-warning btn-sm" >CANCEL</a>
</form>
<?php
echo' </td></tr></table>';
?>
</fieldset>
</div>
<?php
if(isset($_POST['edit']))
{
$user=$_SESSION['Userid'];
$businessdate=$_POST['businesdate'];
$project=$_POST['project'];
$description=encryption($_POST['description']);
$flag=0;
function fileprocessingtoupload()
	{

	$docrefarray=array();
	$outputarray=array();
	$uploadedfilename=array();
	$query=" SELECT FilePath FROM param";
	$sql=DataBasefunction($query);
	$row=mysqli_fetch_array($sql);
	$target_dir =$row['FilePath'];
	for($i=1;$i<4;$i++)
	{
	//$target_dir = "DOCUMENTS/";
	$uploadOk = 1;
	if(($_FILES["document".$i]["name"]!=""))//&&($_POST['refnumber'.$i]!="")
		{
		$timestamp=time();
		$randomnumber=rand(1000,2000);
		$imagename=$timestamp.$randomnumber.'.'.pathinfo(basename($_FILES["document".$i]["name"]),PATHINFO_EXTENSION);
		$target_file = $target_dir .$imagename;
		if(move_uploaded_file($_FILES["document".$i]["tmp_name"], $target_file))
		{
		array_push($uploadedfilename,encryption($target_file));
		if($_POST['refnumber'.$i]!="")
		{
			array_push($docrefarray,encryption(strtoupper($_POST['refnumber'.$i])));
		echo '<script type="text/javascript">
		alert("document '.$_POST['refnumber'.$i] .' uploaded succesfully");
		</script>';}
		else
		{
			array_push($docrefarray,encryption(strtoupper($i)));
		echo '<script type="text/javascript">
		alert("document '.$i .' uploaded succesfully");
		</script>';
		}
		}
		else
		{
		echo '<script type="text/javascript">
		alert("document '.$_POST['refnumber'.$i].' uploading failed");
		</script>';
		}}
	    }
	global $flag;
	$flag=1;
	$outputarray=array($uploadedfilename,$docrefarray);
	return $outputarray;
	}
	
$uploadedfiles=fileprocessingtoupload();
$uploadedfilename=$uploadedfiles[0];
$docref=$uploadedfiles[1];
if($flag==1)
		{       
		$documentnamelist=implode(',',$uploadedfilename).',';
		$docrefnumberlist=implode(',',$docref).',';
$query3="call updatefinancialtransaction('$financialtrnsctnid','$businessdate','$project','$description','$documentnamelist','$docrefnumberlist')";
    
//$query1="UPDATE financial_tran SET BusinessDate='$businessdate' WHERE FinancialTranID='$financialtrnsctnid'";
$sql1=DataBasefunction($query3);	
			if($sql1)
			{
				setcookie("done", 1, time() + 10);
			}
			else
				{
				setcookie("done", -1, time() + 10);
				}
			}}
?>


<div id="popupsucess">
  <div align="center"></div>
    <table align="center"><tr><td align="center">
<img id="success" src="success.PNG" style="height:100px;width:100px"
hidden="true">
<img id="failure" src="failure.PNG" style="height:100px;width:100px"
hidden="true">
<label id="lab"></label></td></tr>
   <tr><td>&nbsp;</td></tr>
   <tr><td align="center" >
   <button id="success_ok" onclick="dones()" class="btn btn-primary
">Done</button>
   </td>
   <tr><td>&nbsp;</td></tr>
   </tr>
</div>
 
     </div>
      
 
 <script src="../bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
 <script src="../bower_components/metisMenu/dist/metisMenu.min.js"></script>
<!-- <script type="text/javascript" src="JS/javascript_Deletefinanciatrans.js"></script>-->
 <script src="../dist/js/sb-admin-2.js"></script>
 <script type="text/javascript" src="JS/javascript_editTransactionForm.js"></script>
 <script type="text/javascript">
    document.write('<link href="JS/jquery-ui-1.11.4.custom/jquery-ui.css" rel="stylesheet" type="text/css" />\n')
    document.write('<script src="JS/jquery-ui-1.11.4.custom/jquery-ui.min.js"><\/script>\n') 
    jQuery(function($){ 
    $('#businessdate').datepicker({
    dateFormat: 'yy-mm-dd',
	maxDate: "+0"
});

})


</script>


 </body>
 </html>
